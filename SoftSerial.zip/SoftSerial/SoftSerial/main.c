/*
 * main.c
 *
 * Created: 21-9-2021 20:06:52
 * Author : Hugo Arends
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <SoftSerial.h>

int main(void)
{
    DDRB = (1<<DDB5);

    SoftSerialInit();
    sei();

    SoftSerialTransmitString("\r\nSoftSerial demo\r\n");

    while (1) 
    {
        if(SoftSerialUnread() > 0)
        {
            char data = SoftSerialReceiveByte();

            switch( data )
            {

                case '1':
                PINB = (1<<PINB5);
                break;

                case 'h':
                SoftSerialTransmitString("hello world!\r\n");
                break;

                case 'H':
                SoftSerialTransmitString("HELLO WORLD!\r\n");
                break;

                default:
                SoftSerialTransmitString("Unknown command\r\n");
                break;
            }

        }
    }
}

